﻿using CardLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //initiate deck
            CardSet myDeck = new CardSet();

            //number of cards in each player's hand
            int howManyCards = 2;

            //player's starting money
            int balance = 10;

            //console colors
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.DarkBlue;

            //loop game until user loses.
            Console.WriteLine("Welcome to the card game.");
            Console.WriteLine("\nHand with two highest total cards wins.");
            Console.WriteLine("Ace is highest card and 2 is lowest.");
            Console.WriteLine("2 card flush is the highest hand.");
            Console.WriteLine("Spade is highest suit followed by heart, diamond and clubs.");
            Console.WriteLine("");
            Console.WriteLine("You have " + balance + " dollars.");
            //intiate buy in for player
            Console.WriteLine("\nBuy in for each hand is $1.");
            Console.WriteLine("Press enter to continue.");
            Console.ReadLine();


            while (balance > 0)
            {
                //player pays buy in
                balance--;

                //reset cards to be reused
                myDeck.ResetUsage();

                //generate hands for both dealer and player
                SuperCard[] computerHand = myDeck.GetCards(howManyCards);
                SuperCard[] playersHand = myDeck.GetCards(howManyCards);

                //sort hands
                Array.Sort(computerHand);
                Array.Sort(playersHand);

                //display dealer and player's hand
                DisplayHands(computerHand, playersHand);


                PlayerDrawsOne(playersHand, myDeck);
                ComputerDrawsOne(computerHand, myDeck);

                //display changed hands
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("FINAL NEW HANDS");
                DisplayHands(computerHand, playersHand);

                //compare to see if dealer or player has greater ranked hand
                //if dealer is greater won = false
                bool won = CompareHands(computerHand, playersHand);

                //won = true => player wins
                //won = false => dealer wins
                if (won)
                {
                    Console.WriteLine("You win!");
                    balance += 2;
                    Console.WriteLine("New balance: " + balance);
                }
                else
                {
                    Console.WriteLine("You lost.");
                    Console.WriteLine("New balance: " + balance);
                }
                
                //ask player to restart loop
                Console.WriteLine("Press enter for another hand.");
                Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("==============NEW GAME==============");
                Console.WriteLine();
                Console.WriteLine();
            }

            // end of program
            Console.WriteLine("Ran out of money to play.");
            Console.WriteLine("Press enter to close program.");
            Console.ReadLine();
    }

        private static void ComputerDrawsOne(SuperCard[] computerHand, CardSet myDeck)
        {
            //if Dealer gets one rank card less than 7 then replace
            for(int i = 0; i < computerHand.Length; i++)
            {
                if (computerHand[i].CardRank < (Rank)7)
                {
                    computerHand[i].inplay = false;
                    computerHand[i] = myDeck.GetOneCard();
                    Console.WriteLine("Dealer changed a card in his hand");
                }
            }
        }

        private static void PlayerDrawsOne(SuperCard[] playersHand, CardSet myDeck)
        {
            //get player's first input on replacement
            Console.WriteLine("Is there any cards you want to replace?");
            Console.WriteLine("Enter one card index and press enter (Enter 0 to replace none): ");
            int input = Convert.ToInt32(Console.ReadLine());

            //initiate local variables
            //this array is for checking if player has already placed the card
            int[] index = new int[playersHand.Length];
            //fill empty array
            for(int j = 0; j < index.Length; j++)
            {
                index[j] = j + 1;
            }
            int holder = input;

            //while player keeps entering index that is not 0 or if all cards in player's
            //hand has not been replaced, keep looping
            while (holder != 0)
            {
                input--;
                //check if index is within player's hand
                for(int i = 0; i <= index.Length - 1; i++)
                {
                    //replace card
                    if(holder == index[i])
                    {
                        //reset old card to be in play again
                        playersHand[input].inplay = false;
                        playersHand[input] = myDeck.GetOneCard();

                        //make replaced card can't be replaced again
                        index[i] = 0;

                        Console.WriteLine("Replacement Successful!");
                        i += index.Length;
                    }
                    //error case where player inputs a card that is already replaced earlier or
                    //the index the player entered is not within their 'hand' to replace
                    if(i == index.Length - 1)
                    {
                        Console.WriteLine("Card has already been replaced or index entered does not exist.");
                    }
                }

                //ask user if they want to replace another card
                Console.WriteLine("Do you want to replace another card?");
                Console.WriteLine("Enter next card index (Enter 0 to replace none): ");
                input = Convert.ToInt32(Console.ReadLine());

                holder = input;
            }
        }

        private static bool Flush(SuperCard[] hand)
        {
            Boolean flush = true;

            for(int i = 1; i < hand.Length; i++)
            {
                if (!hand[i].Equals(hand[i-1]))
                {
                    flush = false;
                }
            }

            return flush;
        }

        private static bool CompareHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            //initiate variables to deal with comparing ranks when
            //both players don't get a flush
            int dealerRank = 0;
            int playerRank = 0;

            //dealer got a flush
            //dealer wins
            if (Flush(computerHand))
            {
                Console.WriteLine("DEALER got a FLUSH!");
                return false;
            }
            //player got a flush
            //player wins
            else if (Flush(playersHand))
            {
                Console.WriteLine("PLAYER got a FLUSH!");
                return true;
            }
            //calculate who has a higher ranking hand
            else
            {
                //dealer's rank
                for (int i = 0; i < computerHand.Length; i++)
                {
                    dealerRank += (int)computerHand[i].CardRank;
                }

                //player's rank
                for (int j = 0; j < playersHand.Length; j++)
                {
                    playerRank += (int)playersHand[j].CardRank;
                }

                //if dealer's total rank is greater than player's return false
                if (dealerRank >= playerRank)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        private static void DisplayHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            //print dealer's hand
            Console.WriteLine("DEALER HAND");   
            for(int i = 0; i < computerHand.Length; i++)
            {
                computerHand[i].Display();
            }

            //print player's hand
            Console.WriteLine("YOUR HAND");
            for(int j = 0; j < playersHand.Length; j++)
            {
                playersHand[j].Display();
            }
        }
    }
}
