﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    class CardHeart : SuperCard
    {
        private Suit _CardSuit = Suit.Heart;
        private Rank _CardRank;

        //set and get suit
        public override Suit CardSuit
        {
            get
            {
                return _CardSuit;
            }
            set
            {
                _CardSuit = Suit.Heart;
            }
        }

        //get card rank
        public override Rank CardRank
        {
            get
            {
                return _CardRank;
            }
        }

        //create card heart object
        public CardHeart(Rank rank)
        {
            _CardRank = rank;
        }

        //display heart card
        public override void Display()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(_CardRank + " of " + _CardSuit + "s ♥");
            Console.ResetColor();
        }
    }
}
