﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    class CardDiamond : SuperCard
    {
        private Suit _CardSuit = Suit.Diamond;
        private Rank _CardRank;

        //set and get suit
        public override Suit CardSuit
        {
            get
            {
                return _CardSuit;
            }
            set
            {
                _CardSuit = Suit.Club;
            }
        }

        //get card rank
        public override Rank CardRank
        {
            get
            {
                return _CardRank;
            }
        }

        //create card diamond card object
        public CardDiamond(Rank rank)
        {
            _CardRank = rank;
        }

        //display diamond card
        public override void Display()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(_CardRank + " of " + _CardSuit + "s ♦");
            Console.ResetColor();
        }
    }
}
