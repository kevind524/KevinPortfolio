﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public class CardSet
    {
        public SuperCard[] cardArray = new SuperCard[52];
        Random random = new Random();

        //create deck of cards
        public CardSet()
        {
            //counter
            int type = 1;
            int counter = 0;
            //loop for each suit
            for (int i = 1; i <= 4; i++)
            {
                //loop for 13 card of same suit
                for (int j = 2; j <= 14; j++)
                {
                    if (type == 1)
                    {
                        cardArray[counter] = new CardClub((Rank)j);
                    }
                    else if (type == 2)
                    {
                        cardArray[counter] = new CardDiamond((Rank)j);
                    }
                    else if (type == 3)
                    {
                        cardArray[counter] = new CardHeart((Rank)j);
                    }
                    else if(type == 4)
                    {
                        cardArray[counter] = new CardSpade((Rank)j);
                    }
                    counter++;
                }
                type++;
            }
        }

        //create hand of cards for players
        public SuperCard[] GetCards(int pnumber)
        {
            //initiate random hand
            SuperCard[] temp = new SuperCard[pnumber];

            //local variable for getting random int
            int randomNumber;

            //counter for loop
            int counter = 0;

            //loop until temp array is filled to return
            while(counter < pnumber)
            {
                //get random int
                randomNumber = random.Next(0, 51);

                //if card isn't in play add it to temp array
                if(cardArray[randomNumber].inplay == false)
                {
                    //add random card to temp array
                    temp[counter] = cardArray[randomNumber];

                    //make random card now in use
                    cardArray[randomNumber].inplay = true; 
                    //iterate counter
                    counter++;
                }
            }

            //return hand
            return temp;
        }

        //Reset all 52 cards to false as they are not in play
        public void ResetUsage()
        {
            for(int i = 0; i < 52; i++)
            {
                cardArray[i].inplay = false;
            }
        }

        public SuperCard GetOneCard()
        {
            //initiate card
            SuperCard temp = null;

            //initiate random number
            int randomNumber;

            //initiate 
            Rank r;
            Suit s;

            //loop until card is found
            while(temp == null)
            {
                randomNumber = random.Next(0, 51);

                //if card found add card to 'temp'
                if (cardArray[randomNumber].inplay == false)
                {
                    r = cardArray[randomNumber].CardRank;
                    s = cardArray[randomNumber].CardSuit;

                    if (s == (Suit)1)
                    {
                        temp = new CardClub((Rank)r);
                    }
                    else if (s == (Suit)2)
                    {
                        temp = new CardDiamond((Rank)r);
                    }
                    else if (s == (Suit)3)
                    {
                        temp = new CardHeart((Rank)r);
                    }
                    else if(s == (Suit)4)
                    {
                        temp = new CardSpade((Rank)r);
                    }

                    cardArray[randomNumber].inplay = true;
                }
            }
            //return card
            return temp;
        }
    }
}