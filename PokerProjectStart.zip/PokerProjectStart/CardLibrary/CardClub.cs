﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    class CardClub : SuperCard
    {
        private Suit _CardSuit = Suit.Club;
        private Rank _CardRank;

        //set and get suit
        public override Suit CardSuit
        {
            get
            {
                return _CardSuit;
            }
            set
            {
                _CardSuit = Suit.Club;
            }
        }

        //get card rank
        public override Rank CardRank
        {
            get
            {
                return _CardRank;
            }
        }

        //create card club card object
        public CardClub(Rank rank)
        {
                _CardRank = rank;
        }

        //display club card
        public override void Display()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(_CardRank + " of " + _CardSuit + "s ♣");
            Console.ResetColor();
        }
    }
}
