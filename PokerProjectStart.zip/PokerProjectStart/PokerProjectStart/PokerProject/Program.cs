﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerProject
{
    class Program
    {
        static void Main(string[] args)
        {
            // a. Create an instance of your CardSet class, and call it myDeck.
            CardLibrary.CardSet myDeck = new CardLibrary.CardSet();
            
            // b. Build a loop that does a Console.WriteLine 52 times.
            // inside the loop, use this line to write out the 52 unique cards.
            for (int i = 0; i <= 52; i++)
            {
                Console.WriteLine(myDeck.cardArray[i].CardRank + " of " + myDeck.cardArray[i].CardSuit);
                //Console.WriteLine(CardLibrary.CardSet.cardArray[i].CardRank + " of " + CardLibrary.CardSet.cardArray[i].CardSuit);
            }
            // end of program
            Console.ReadLine();

        }
    }
}
