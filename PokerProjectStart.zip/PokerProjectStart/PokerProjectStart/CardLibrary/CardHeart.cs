﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    class CardHeart : SuperCard
    {
        private Suit _CardSuit = Suit.Club;
        private Rank _CardRank;

        public override Suit CardSuit
        {
            get
            {
                return _CardSuit;
            }
            set
            {
                _CardSuit = Suit.Heart;
            }
        }

        public CardHeart(Rank rank)
        {
            _CardRank = rank;
            _CardSuit = Suit.Heart;
        }
        public override Rank CardRank
        {
            get
            {
                return _CardRank;
            }
        }
    }
}
