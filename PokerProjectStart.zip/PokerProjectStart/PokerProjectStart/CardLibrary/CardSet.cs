﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public class CardSet
    {
        public SuperCard[] cardArray = new SuperCard[52];

        public CardSet()
        {
            //counter
            int type = 1;
            int counter = 0;
            Rank rank;

            //loop for each suit
            for (int i = 1; i <= 4; i++)
            {
                //loop for 13 card of same suit
                for (int j = 2; j <= 14; j++)
                {
                    rank = (Rank)j;
                    if (type == 1)
                    {
                        cardArray[counter] = new CardClub(rank);
                        Console.WriteLine(cardArray[counter].CardRank);
                    }
                    else if (type == 2)
                    {
                        cardArray[counter] = new CardDiamond(rank);
                        Console.WriteLine(cardArray[counter].CardRank);
                    }
                    else if (type == 3)
                    {
                        cardArray[counter] = new CardHeart(rank);
                        Console.WriteLine(cardArray[counter].CardRank);
                    }
                    else
                    {
                        cardArray[counter] = new CardSpade(rank);
                        Console.WriteLine(cardArray[counter].CardRank);
                        Console.WriteLine(cardArray[counter].CardSuit);
                    }
                    counter++;
                }
                type++;
            }
            Console.ReadLine();
        }
    }
}
