﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    class CardDiamond : SuperCard
    {
        private Suit _CardSuit = Suit.Diamond;
        private Rank _CardRank;

        public override Suit CardSuit
        {
            get
            {
                return _CardSuit;
            }
            set
            {
                _CardSuit = Suit.Club;
            }
        }

        public CardDiamond(Rank rank)
        {
            _CardRank = rank;
            _CardSuit = Suit.Diamond;
        }
        public override Rank CardRank
        {
            get
            {
                return _CardRank;
            }
        }
    }
}
