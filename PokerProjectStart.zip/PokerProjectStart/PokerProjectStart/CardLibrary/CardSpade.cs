﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    class CardSpade : SuperCard
    {
        private Suit _CardSuit = Suit.Spade;
        private Rank _CardRank;

        public override Suit CardSuit
        {
            get
            {
                return _CardSuit;
            }
            set
            {
                _CardSuit = Suit.Spade;
            }
        }

        public CardSpade(Rank rank)
        {
            _CardRank = rank;
            _CardSuit = Suit.Spade;
        }
        public override Rank CardRank
        {
            get
            {
                return _CardRank;
            }
        }
    }
}
