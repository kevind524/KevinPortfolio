﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Dao_Kevin.Models;
using Microsoft.Extensions.Configuration;
using Dao_Kevin.DAL;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Http;


namespace Dao_Kevin.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration configuration;

        public  HomeController(IConfiguration config)
        {
            this.configuration = config;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Page2(Person person)
        {
            DALPerson dp = new DALPerson(configuration);
            int uID = dp.addUser(person);

            person.UID = uID;

            HttpContext.Session.SetString("uID", uID.ToString());
            return View(person);
        }
        
        public IActionResult EditPerson()
        {
            int uID = Convert.ToInt32(HttpContext.Session.GetString("uID"));

            DALPerson dp = new DALPerson(configuration);
            Person person = dp.getPerson(uID);

            return View(person);
        }

        public IActionResult UpdatePerson(Person person)
        {
            person.UID = Convert.ToInt32(HttpContext.Session.GetString("uID"));
            DALPerson dp = new DALPerson(configuration);
            dp.UpdateUser(person);

            return View("Page2", person);
        }

        public IActionResult DeletePerson()
        {
            string uID = HttpContext.Session.GetString("uID");
            DALPerson dp = new DALPerson(configuration);

            Person person = dp.getPerson(Convert.ToInt32(uID));

            dp.DeletePerson(Convert.ToInt32(uID));

            return View(person);
        }
    }
}