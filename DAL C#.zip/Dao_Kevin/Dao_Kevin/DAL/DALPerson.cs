﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dao_Kevin.Models;
using System.Data.SqlClient;

/*
 * This file is subject to a lot of change but is probably one of the most important files we need to get working.
 * This is our file that will add new users to the SQL database, check if they are in SQL server and other log in
 * things.
 */
namespace Dao_Kevin.DAL
{
    public class DALPerson
    {
        public IConfiguration configuration { get; }

        public DALPerson(IConfiguration config)
        {
            configuration = config;
        }

        
        public string AddPerson(Models.Person person)
        {
            return person.ToString();
        }

        //add user to database upon registering on webpage
        public int addUser(Person person)
        {
            //connect to database
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //create query command to enter data from webpage into SQL database
            // @ values are kind of like a placeholder
            //
            //NOTE: This query is supposed to enter information into the Person's table ONLY
            //      In other words this query isn't done yet without the SQL Person table being final
            string query = "INSERT INTO [dbo].[Persons]([FirstName],[LastName],[PersonType],[Password],[PersonLogin])" +
                "VALUES(@firstname, @lastName, @personType, HASHBYTES('SHA2_512', @password), @userName);" +
                "SELECT SCOPE_IDENTITY() as id;";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@firstname", person.firstName);
            cmd.Parameters.AddWithValue("@lastName", person.lastName);
            cmd.Parameters.AddWithValue("@personType", "Volunteer");
            cmd.Parameters.AddWithValue("@password", person.Password);
            cmd.Parameters.AddWithValue("@userName", person.userName);

            // execute query to SQL database
            SqlDataReader reader = cmd.ExecuteReader();
            
            reader.Read();
            int uID = Convert.ToInt32(reader[0].ToString()); //I think this is used as the current session ID for the website
                                                             //This make it so that the user who goes through different pages on the website
                                                             //is still logged in as the same person

            reader.Close(); //end query

            /*create query command
            //
            //NOTE: This query is supposed to enter information for username and password if we have
            //      it in a seperate table from Person
            string queryPassword = "SET IDENTITY_INSERT [dbo].[Persons] ON;" +
                "INSERT INTO [dbo].[Persons]([PersonID])" +
                "VALUES(@personID);" +
                "SET IDENTITY_INSERT [dbo].[Persons] OFF;";
            SqlCommand cmd2 = new SqlCommand(queryPassword, conn);
            cmd2.Parameters.AddWithValue("@personID", uID); //uID is their unique ID identifier. Basically their own primary key

            // execute query
            reader = cmd2.ExecuteReader();
            reader.Read();
            reader.Close();

            //close connection
            conn.Close();
            */

            //create query command
            string queryAddress = "INSERT INTO [dbo].[Address]([FullAddress],[ZipCode],[City],[State])" +
                "VALUES(@address, @zipCode, @city, @state);";
            SqlCommand cmd3 = new SqlCommand(queryAddress, conn);
            cmd3.Parameters.AddWithValue("@address", person.address);
            cmd3.Parameters.AddWithValue("@zipCode", person.zipCode);
            cmd3.Parameters.AddWithValue("@city", person.city);
            cmd3.Parameters.AddWithValue("@state", person.state);

            // execute query
            reader = cmd3.ExecuteReader();
            reader.Read();
            reader.Close();

            //close connection
            conn.Close();
            

            return uID; //return session id
        }

        internal PersonShort CheckLogInCredentials(LogInCredentials lic)
        {
            PersonShort SPerson = new PersonShort();

            try
            {
                //connect to database
                string connStr = configuration.GetConnectionString("MyConnString");
                SqlConnection conn = new SqlConnection(connStr);
                conn.Open();

                //create query
                //check if user's username and password is in database
                string query = "SELECT Persons.PersonID, Persons.FirstName " +
                    "FROM Persons WHERE Persons.PersonLogin = @UName AND Persons.Password = HASHBYTES('SHA2_512', @password)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UName", lic.UserName);
                cmd.Parameters.AddWithValue("@Password", lic.UserPassword);

                //execute query
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();

                //add results to object PersonShort SPerson 
                SPerson.FName = reader["FirstName"].ToString();
                SPerson.PersonID = reader["PersonID"].ToString();

                /*
                 * 
                 * query = ""; //query to enter data into Dates table
                 * 
                 * cmd = new SqlCommand(query, conn);
                 * cmd.Parameters.AddWithValue(); //add values into Dates table
                 * 
                 * SqlDataReader reader = cmd.ExecuteReader();
                 * reader.Read();
                 * 
                 */


                //exit query
                //close connection to database
                reader.Close();
                conn.Close();

            }
            catch 
            {
                SPerson.FName = null;
                SPerson.PersonID = null;
            }
            //if they are in database then not NULL
            //if they aren't in database then NULL
            return SPerson;
        }

        //method gets all information on a person logged in
        public Person getPerson(int uID)
        {
            Person person = new Person();

            //connect to database
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //create query
            //get information on them in database
            string query = "SELECT [FirstName],[LastName],[email],[phone],[address],[PersonID],[UserName]" +
                "FROM[dbo].[Persons] " +
                "WHERE [PersonID] = @uID"; //note we are searching for them through their unique uID
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@uID", uID);

            //execute query
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            //add results to object Person person
            person.firstName = reader["FName"].ToString();
            person.lastName = reader["LName"].ToString();
            person.email = reader["email"].ToString();
            person.phone = reader["phone"].ToString();
            person.address = reader["address"].ToString();
            person.userName = reader["UserName"].ToString();

            //exit query
            //close connection to database
            reader.Close();
            conn.Close();

            //return information on person
            return person;
        }

        //method updates user information
        public void UpdateUser(Person person)
        {
            //connect to database
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //create query
            //updates user information in database
            string query = "UPDATE [dbo].[Person] " +
                "SET [FName] = @FName," +
                "[LName] = @LName," +
                "[email] = @email," +
                "[phone] = @phone," +
                "[address] = @address," +
                "[UserName] = @userName " +
                "WHERE PersonID = @PersonID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@FName", person.firstName);
            cmd.Parameters.AddWithValue("@LName", person.lastName);
            cmd.Parameters.AddWithValue("@email", person.email);
            cmd.Parameters.AddWithValue("@phone", person.phone);
            cmd.Parameters.AddWithValue("@address", person.address);
            cmd.Parameters.AddWithValue("@userName", person.userName);
            cmd.Parameters.AddWithValue("@PersonID", person.UID.ToString());

            //execute query
            cmd.ExecuteNonQuery();
            
            //NOTE: not READING information here so don't need to exit query
            //close connection
            conn.Close();
        }

        //method deletes person from database
        internal void DeletePerson(int uID)
        {
            //connect to database
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //create query
            //delete user from database: credentials table
            string query = "DELETE FROM [dbo].[Credentials] " +
                "WHERE PersonID = @PersonID";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("PersonID", uID.ToString());

            //execute query
            cmd.ExecuteNonQuery();

            //create query
            //delete user from database: person table
            query = "DELETE FROM [dbo].[Person] " +
                "WHERE PersonID = @PersonID";
            cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("PersonID", uID.ToString());

            //execute query
            cmd.ExecuteNonQuery();

            //NOTE: not READING information here so don't need to exit query
            //close connection
            conn.Close();
        }
    }
}
