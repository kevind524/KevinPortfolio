﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dao_Kevin.Models;
using System.Data.SqlClient;


namespace Dao_Kevin.DAL
{
    public class DALPerson
    {
        public IConfiguration configuration { get; }

        public DALPerson(IConfiguration config)
        {
            configuration = config;
        }

        public string AddPerson(Models.Person person)
        {
            return person.ToString();
        }

        public int addUser(Person person)
        {
            //connect to db
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //create query command
            string query = "INSERT INTO [dbo].[Person]([FName],[LName],[email],[phone],[address],[UserName])" +
                "VALUES(@firstname, @lastName, @email, @phone, @address, @userName)" +
                "SELECT SCOPE_IDENTITY() as id;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@firstname", person.firstName);
            cmd.Parameters.AddWithValue("@lastName", person.lastName);
            cmd.Parameters.AddWithValue("@email", person.email);
            cmd.Parameters.AddWithValue("@phone", person.phone);
            cmd.Parameters.AddWithValue("@address", person.address);
            cmd.Parameters.AddWithValue("@userName", person.userName);

            // execute query
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            int uID = Convert.ToInt32(reader[0].ToString());

            reader.Close();

            //create query command
            string queryPassword = "INSERT INTO [dbo].[Credentials]([PersonID],[Password])" +
                "VALUES(@personID,@password)";
            SqlCommand cmd2 = new SqlCommand(queryPassword, conn);
            cmd2.Parameters.AddWithValue("personID", uID);
            cmd2.Parameters.AddWithValue("@password", person.password);

            // execute query
            reader = cmd2.ExecuteReader();
            reader.Read();
            reader.Close();

            //close connection
            conn.Close();
            return uID;
        }

        internal PersonShort CheckLogInCredentials(LogInCredentials lic)
        {
            PersonShort SPerson = new PersonShort();

            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "SELECT Person.PersonID, Person.FName " +
                "FROM Person INNER JOIN Credentials ON Person.PersonID = Credentials.PersonID " +
                "WHERE Person.UserName = @UName AND Credentials.Password = @Password";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@UName", lic.UserName);
            cmd.Parameters.AddWithValue("@Password", lic.UserPassword);

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            SPerson.FName = reader["FName"].ToString();
            SPerson.PersonID = reader["PersonID"].ToString();

            reader.Close();
            conn.Close();

            return SPerson;
        }

        public Person getPerson(string uID)
        {
            Person person = new Person();

            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "SELECT [FName],[LName],[email],[phone],[address],[PersonID],[UserName]" +
                "FROM[dbo].[Person] " +
                "WHERE [PersonID] = @uID";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@uID", uID);

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            person.firstName = reader["FName"].ToString();
            person.lastName = reader["LName"].ToString();
            person.email = reader["email"].ToString();
            person.phone = reader["phone"].ToString();
            person.address = reader["address"].ToString();
            person.userName = reader["UserName"].ToString();

            reader.Close();
            conn.Close();

            return person;
        }

        public void UpdateUser(Person person)
        {
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "UPDATE [dbo].[Person] " +
                "SET [FName] = @FName," +
                "[LName] = @LName," +
                "[email] = @email," +
                "[phone] = @phone," +
                "[address] = @address," +
                "[UserName] = @userName " +
                "WHERE PersonID = @PersonID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@FName", person.firstName);
            cmd.Parameters.AddWithValue("@LName", person.lastName);
            cmd.Parameters.AddWithValue("@email", person.email);
            cmd.Parameters.AddWithValue("@phone", person.phone);
            cmd.Parameters.AddWithValue("@address", person.address);
            cmd.Parameters.AddWithValue("@userName", person.userName);
            cmd.Parameters.AddWithValue("@PersonID", person.UID.ToString());

            cmd.ExecuteNonQuery();

            conn.Close();
        }

        internal void DeletePerson(int uID)
        {
            string connStr = configuration.GetConnectionString("MyConnString");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "DELETE FROM [dbo].[Credentials] " +
                "WHERE PersonID = @PersonID";
            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("PersonID", uID.ToString());
            cmd.ExecuteNonQuery();

            query = "DELETE FROM [dbo].[Person] " +
                "WHERE PersonID = @PersonID";
            cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("PersonID", uID.ToString());

            cmd.ExecuteNonQuery();

            conn.Close();
        }
    }
}
