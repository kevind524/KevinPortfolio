﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dao_Kevin.Models;
using Microsoft.Extensions.Configuration;

namespace Dao_Kevin.DAL
{
    public class DALSalesTransaction
    {
        private IConfiguration configuration;

        public DALSalesTransaction(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        internal Purchase OneClickBuy(string pID, string uID, int manyPurchasedProducts)
        {
            SalesTransaction st = new SalesTransaction();
            st.PersonID = uID;
            st.ProductID = pID;
            st.PQuantity = 1;
            st.SalesDataTime = DateTime.Now;
            this.AddTransaction(st);

            Purchase purchase = new Purchase();
            purchase.Person = new DALPerson(configuration).getPerson(uID);
            purchase.Product = new DALProducts(configuration).GetAllProducts(pID);

            new DALProducts(configuration).UpdateInventory(pID, manyPurchasedProducts * -1);

            return purchase;
        }
    }
}
