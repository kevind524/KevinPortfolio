﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class SalesTransaction
    {
        public string ProductID { get; set; }
        public string PersonID { get; set; }
        public int PQuantity { get; set; }
        public DateTime SalesDataTime { get; set; }
    }
}
