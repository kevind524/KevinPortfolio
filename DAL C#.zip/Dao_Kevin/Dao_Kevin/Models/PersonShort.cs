﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class PersonShort
    {
        public string PersonID { get; internal set; }
        public string FName { get; internal set; }
    }
}
