﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class LogInCredentials
    {
        public string UserName { get; set; }
        public String UserPassword { get; set; }
    }
}
