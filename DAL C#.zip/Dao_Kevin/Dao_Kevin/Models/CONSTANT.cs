﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class CONSTANT
    {
        static public string SESSION_PERSONID = "SESSION";
        static public string SESSION_PERSONFNAME = "FName";
    }
}
