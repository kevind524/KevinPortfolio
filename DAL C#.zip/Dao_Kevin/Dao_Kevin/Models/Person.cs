﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace Dao_Kevin.Models
{
    public class Person
    {

        // add some code here. 4/20/19  Lin
        public String userName { get; set; }

        public string Password { get; set; }

        public String ConfirmPassword { get; set; }

        public String firstName { get; set; }

        public String lastName { get; set; }

        public String personType { get; set; }

        public String email { get; set; }

        public String phone { get; set; }

        public String address { get; set; }

        public String city { get; set; }

        public String state { get; set; }

        public String zipCode { get; set; }

        public int UID { get; set; }
    }
}
