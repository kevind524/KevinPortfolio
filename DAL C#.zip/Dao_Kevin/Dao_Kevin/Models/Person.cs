﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dao_Kevin.Models
{
    public class Person
    {
        public String firstName { get; set; }
        public String lastName { get; set; }
        public String email { get; set; }
        public String phone { get; set; }
        public String address { get; set; }
        public String userName { get; set; }
        public String password { get; set; }
        public int UID { get; set; }
    }
}
