USE Dao_SPROC_Portfolio
GO

-- DROP PROCEDURE if already made
IF ( OBJECT_ID('uspUpsertTitle') IS NOT NULL ) 
   DROP PROCEDURE uspUpsertTitle
GO

-- CREATE PROCEDURE
CREATE PROCEDURE uspUpsertTitle
@Title_ID INT,
@Title VARCHAR(30),
@Title_Type_ID INTEGER,
@Genre_ID INTEGER

AS
BEGIN

	-- Check if ID is there upon search
	SET NOCOUNT ON;
	IF(@Title_ID IS NOT NULL AND
		(NOT EXISTS(SELECT NULL FROM dbo.Title WHERE Title_ID = @Title_ID)))
		THROW 51000, 'Title ID not valid', 1

	-- If ID is not there then create ID searched for with values
	IF(@Title_ID IS NULL)
		INSERT INTO dbo.Title
		(
		Title,
		Title_Type_ID,
		Genre_ID
		)
		VALUES
		(
		@Title,
		@Title_Type_ID,
		@Genre_ID
		)

	-- Update existing values of ID if ID is found
	ELSE
	   UPDATE dbo.Title
	     SET Title = ISNULL(@Title, Title),
			 Title_Type_ID = ISNULL(@Title_Type_ID, Title_Type_ID),
			 Genre_ID = ISNULL(@Genre_ID, Genre_ID)
	   WHERE dbo.Title.Title_ID = @Title_ID
END;

-- Test Cases
EXEC uspUpsertTitle NULL, 'abc', 3, 4;
EXEC uspUpsertTitle 1, 'a', 1, 2;
EXEC uspUpsertTitle 5, 'defghijklmnop', 4, 3;
EXEC uspUpsertTitle NULL, 'tennis is fun', 4, 4;
EXEC uspUpsertTitle 100, 'b', 1, 2; -- error handling

-- SELECT * FROM dbo.Title;