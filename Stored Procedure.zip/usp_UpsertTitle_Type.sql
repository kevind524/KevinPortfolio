USE Dao_SPROC_Portfolio
GO

-- DROP PROCEDURE if already made
IF ( OBJECT_ID('uspUpsertTitle_Type') IS NOT NULL ) 
   DROP PROCEDURE uspUpsertTitle_Type
GO

-- CREATE PROCEDURE
CREATE PROCEDURE uspUpsertTitle_Type
@Title_Type_ID INT,
@Type VARCHAR(5),
@Media VARCHAR(10)

AS
BEGIN

	-- Check if ID is there upon search
	SET NOCOUNT ON;
	IF(@Title_Type_ID IS NOT NULL AND
		(NOT EXISTS(SELECT NULL FROM dbo.Title_Type WHERE Title_Type_ID = @Title_Type_ID)))
		THROW 51000, 'Title Type ID not valid', 1

	-- If ID is not there then create ID searched for with values
	IF(@Title_Type_ID IS NULL)
		INSERT INTO dbo.Title_Type
		(
		Type,
		Media
		)
		VALUES
		(
		@Type,
		@Media
		)

	-- Update existing values of ID if ID is found
	ELSE
	   UPDATE dbo.Title_Type
	     SET Type = ISNULL(@Type, Type),
			 Media = ISNULL(@Media, Media)
	   WHERE dbo.Title_Type.Title_Type_ID = @Title_Type_ID
END;

-- Test Cases
EXEC uspUpsertTitle_Type NULL, 'abc', '123';
EXEC uspUpsertTitle_Type 1, 'a', 'b';
EXEC uspUpsertTitle_Type 2, 'defghijklmnop', 'qrstuvwxyz';
EXEC uspUpsertTitle_Type NULL, 'tennis is fun', 'on a sunny day';
EXEC uspUpsertTitle_Type 100, 'b', 'c'; -- error handling

-- SELECT * FROM dbo.Title_Type;