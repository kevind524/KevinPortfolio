-- DROP DATABASE Assignment6_DAO;

-- CREATE DATABASE
CREATE DATABASE Dao_SPROC_Portfolio;
GO

-- USE DATABASE
USE Dao_SPROC_Portfolio;
GO

-- CREATE TABLES
CREATE TABLE Title_Type
	(Title_Type_ID INTEGER IDENTITY(1,1) CONSTRAINT PK_Type PRIMARY KEY,
	Type VARCHAR(5),
	Media VARCHAR(10));
GO

CREATE TABLE Genre
	(Genre_ID INTEGER IDENTITY(1,1) CONSTRAINT PK_Genre PRIMARY KEY,
	Genre VARCHAR(30));
GO

CREATE TABLE Title
	(Title_ID INTEGER IDENTITY(1,1) CONSTRAINT PK_Title PRIMARY KEY,
	Title VARCHAR(30),
	Title_Type_ID INTEGER,
	Genre_ID INTEGER);
GO

-- ADD CONSTRAINTS
ALTER TABLE Title ADD CONSTRAINT FK_Title_Title_Type
FOREIGN KEY (Title_Type_ID) REFERENCES Title_Type(Title_Type_ID);

ALTER TABLE Title ADD CONSTRAINT FK_TITLE_GENRE_ID
FOREIGN KEY (Genre_ID) REFERENCES Genre(Genre_ID);
GO

-- INSERT VALUES INTO TABLES
-- SELECT * FROM Genre;
INSERT INTO Genre VALUES
	('hello'),
	('this'),
	('is'),
	('a'),
	('test'),
	('do'),
	('you'),
	('like'),
	('apples'),
	('they'),
	('are'),
	('good'),
	('for'),
	('you'),
	('to eat');
GO

-- SELECT * FROM Title_Type
INSERT INTO Title_Type VALUES
	('Nice','Job'),
	('Good', 'Work');
GO

-- SELECT * FROM Title;
INSERT INTO Title VALUES
	('its', 1, 2),
	('a', 1, 2),
	('wonderful', 1, 2),
	('day', 1, 2),
	('in', 1, 2),
	('the', 1, 2),
	('neighborhood', 2, 1),
	('a', 2, 1),
	('wonderful', 2, 1),
	('day', 2, 1);
GO