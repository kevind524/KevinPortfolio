USE Dao_SPROC_Portfolio
GO

-- DROP PROCEDURE if already made
IF ( OBJECT_ID('uspUpsertGenre') IS NOT NULL ) 
   DROP PROCEDURE uspUpsertGenre
GO

-- CREATE PROCEDURE
CREATE PROCEDURE uspUpsertGenre
@Genre_ID INT,
@Genre VARCHAR(30)

AS
BEGIN

	-- Check if ID is there upon search
	SET NOCOUNT ON;
	IF(@Genre_ID IS NOT NULL AND
		(NOT EXISTS(SELECT NULL FROM dbo.Genre WHERE Genre_ID = @Genre_ID)))
		THROW 51000, 'Genre ID not valid', 1

	-- If ID is not there then create ID searched for with values
	IF(@Genre_ID IS NULL)
		INSERT INTO dbo.Genre
		(
		Genre
		)
		VALUES
		(
		@Genre
		)

	-- Update existing values of ID if ID is found
	ELSE
	   UPDATE dbo.Genre
	     SET Genre = ISNULL(@Genre, Genre)
	   WHERE dbo.Genre.Genre_ID = @Genre_ID
END;

-- Test Cases
EXEC uspUpsertGenre NULL, 'abc';
EXEC uspUpsertGenre 1, 'a';
EXEC uspUpsertGenre 5, 'defghijklmnop';
EXEC uspUpsertGenre NULL, 'tennis is fun';
EXEC uspUpsertGenre 100, 'b'; -- error handling

-- SELECT * FROM dbo.Genre;